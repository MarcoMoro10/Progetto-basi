# carichiamo il dataset
df<-read.csv('data.csv')
num.df<-df
#ripuliamo il dataset
df$X<-NULL # eliminiamo la colonna con valori nulli
# ripulisco il dataset
df<-na.omit(df)
#Controlliamo che la diagnosi sia factor
df$diagnosis<-as.factor(df$diagnosis)
levels(df$diagnosis)
print(df$diagnosis)
# controllo che tutti gli id siano dei numeri interi
df$id<-as.integer(df$id)
#essendo molto squilibrati gli id delle persone non li consideriamo, essendo alcuni rappresentati a 6 cifre ed altri addirittura a 9
df <- df[,-1]
# sostituiamo le variabili in lettera dei factor come rappresentazione dei benigni e maligni
df$diagnosis <- factor(ifelse(df$diagnosis=="B","Benign","Malignant"))
#elimino gli outlier delle colonne mean, controlliamo per ogni colonna gli outlier.
#eliminazione outlier radius_mean
#trovo quantile
quantile <- quantile(df$radius_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$radius_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$radius_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$radius_mean > (quantile[1] - 1.5*InterquantileRange) & df$radius_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto
#ripeto il processo precedente per tutti mean
#texture_mean
quantile <- quantile(df$texture_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$texture_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$texture_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$texture_mean > (quantile[1] - 1.5*InterquantileRange) & df$texture_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto
#perimeter_mean
quantile <- quantile(df$perimeter_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$perimeter_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$perimeter_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$perimeter_mean > (quantile[1] - 1.5*InterquantileRange) & df$perimeter_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto
#area mean
quantile <- quantile(df$area_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$area_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$area_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$area_mean > (quantile[1] - 1.5*InterquantileRange) & df$area_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto
#smothness_mean
quantile <- quantile(df$smoothness_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$smoothness_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$smoothness_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$smoothness_mean > (quantile[1] - 1.5*InterquantileRange) & df$smoothness_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto
#compactness mean
quantile <- quantile(df$compactness_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$compactness_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$compactness_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$compactness_mean > (quantile[1] - 1.5*InterquantileRange) & df$compactness_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto
#concavity mean
quantile <- quantile(df$concavity_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$concavity_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$concavity_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$concavity_mean > (quantile[1] - 1.5*InterquantileRange) & df$concavity_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto
#concave point mean
quantile <- quantile(df$concave.points_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$concave.points_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$concave.points_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$concave.points_mean > (quantile[1] - 1.5*InterquantileRange) & df$concave.points_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto
#symmetry mean
quantile <- quantile(df$symmetry_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$symmetry_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$symmetry_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$symmetry_mean > (quantile[1] - 1.5*InterquantileRange) & df$symmetry_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto
#fractal dimension mean
quantile <- quantile(df$fractal_dimension_mean);
print(quantile)
#quantile tra il 25% e il 75%
quantile<-quantile(df$fractal_dimension_mean, probs=c(.25, .75), na.rm = FALSE)
print(quantile)
#calcolo range
InterquantileRange<-IQR(df$fractal_dimension_mean)
print(InterquantileRange)
up <-  quantile[2]+1.5*InterquantileRange # Upper Range  
low<- quantile[1]-1.5*InterquantileRange # Lower Range
#prendo solo i dati non errati
resto<- subset(df, df$fractal_dimension_mean > (quantile[1] - 1.5*InterquantileRange) & df$fractal_dimension_mean < (quantile[2]+1.5*InterquantileRange))
df<-resto

df2<-df
#numero grandezza df
N<-nrow(df)
#splitting
N.train <- 350
N.test <- 48
N.val <- 60
train.sample <- sample(N, N.train)# costruire un vettore di elementi che va da 1 a n degli ntrain
df.train <- df[train.sample, ] # [righe, colonne] estrazione degli elementiper costruire i dataset di training
df.test <- df[-train.sample, ]

val.sample <- sample(N.test + N.val, N.val)# costruzione set di validation, estraiamo un vettore di n val, da 1 a nval+ntest
df.val <- df.test[val.sample, ]
df.test <- df.test[-val.sample, ]
# Dimenticare dell'esistenza del dataframe di partenza
df <- df.train
N <- nrow(df)

#install.packages("ggplot2")
library(ggplot2)

esito<-rep(c("Benign","Malignant"),2)
n.pazienti<-c(nrow(df[df$diagnosis=="Benign" ,]),
              nrow(df[df$diagnosis=="Malignant",]))       
              
data<-data.frame(esito,n.pazienti)
ggplot(data,aes(fill=esito,y=n.pazienti,x=esito))+
  geom_bar(position = "dodge", stat = "identity")+guides(fill=guide_legend(title="paziente ha il cancro al seno?"))

# creazione grafico di densit? per radius mean
esito<-rep(c("Bening","Malignant"),350)#fill
y<-c(df$radius_mean)
data <- data.frame(esito,y)

ggplot(data,aes(x=y, fill=esito))+ geom_density(alpha=0.3) +  guides(fill = guide_legend(title = "radius mean"))

#creazione grafico di densit? texture mean
y<-c(df$texture_mean)
data <- data.frame(esito,y)



ggplot(data, aes(x = y, fill = esito)) + geom_density(alpha = 0.3) +
  
  
  
  guides(fill = guide_legend(title = "texture mean"))




#creazione grafico di densit? perimeter mean
y<-c(df$perimeter_mean)
data <- data.frame(esito,y)



ggplot(data, aes(x = y, fill = esito)) + geom_density(alpha = 0.3) +
  
  guides(fill = guide_legend(title = "perimeter mean"))




#creazione grafico di densit? area mean
y<-c(df$area_mean)
data <- data.frame(esito,y)



ggplot(data, aes(x = y, fill = esito)) + geom_density(alpha = 0.3) +
  
  guides(fill = guide_legend(title = "area mean"))



#creazione grafico di densit? smoothness mean
y<-c(df$smoothness_mean)
data <- data.frame(esito,y)



ggplot(data, aes(x = y, fill = esito)) + geom_density(alpha = 0.3) +
  
  guides(fill = guide_legend(title = "smoothness mean"))




#creazione grafico di densit? compactness mean
y<-c(df$compactness_mean)
data <- data.frame(esito,y)



ggplot(data, aes(x = y, fill = esito)) + geom_density(alpha = 0.3) +
  
  guides(fill = guide_legend(title = "compactness mean"))




#creazione grafico di densit? concavity mean
y<-c(df$concavity_mean)
data <- data.frame(esito,y)



ggplot(data, aes(x = y, fill = esito)) + geom_density(alpha = 0.3) +
  
  guides(fill = guide_legend(title = "concavity mean"))




#creazione grafico di densit? concave.points mean
y<-c(df$concave.points_mean)
data <- data.frame(esito,y)



ggplot(data, aes(x = y, fill = esito)) + geom_density(alpha = 0.3) +
  
  guides(fill = guide_legend(title = "concave.points mean"))



#creazione grafico di densit? symmetry mean
y<-c(df$symmetry_mean)
data <- data.frame(esito,y)



ggplot(data, aes(x = y, fill = esito)) + geom_density(alpha = 0.3) +
  
  guides(fill = guide_legend(title = "symmetry mean"))




#creazione grafico di densit? fractal_dimension mean
y<-c(df$fractal_dimension_mean)
data <- data.frame(esito,y)



ggplot(data, aes(x = y, fill = esito)) + geom_density(alpha = 0.3) +
  
  guides(fill = guide_legend(title = "fractal_dimension mean"))

# creazione box radius mean
y<-c(df$radius_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2)
# creazione box texture mean
y<-c(df$texture_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2)
# creazione box perimeter mean
y<-c(df$perimeter_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2)
# creazione box area mean
y<-c(df$area_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2)
# creazione box smothness mean
y<-c(df$smoothness_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2)
# creazione box compactness mean
y<-c(df$compactness_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2) 
# creazione box concavity mean
y<-c(df$concavity_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2) 
# creazione box convaty_points mean
y<-c(df$concave.points_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2) 
# creazione box symmetry mean
y<-c(df$symmetry_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2) 
# creazione box fractal dimension
y<-c(df$fractal_dimension_mean)
data <- data.frame(esito,y)
ggplot(data, aes(x=esito, y = y)) + geom_boxplot(fill= "blue", alpha = 0.2) 

#creazione matrice di correlazione
#creazione matrici di correlazione

#install.packages("corrplot")
library(corrplot)
cor.matrix <- cor(num.df[,3:11])



corrplot(cor.matrix, method = "color", outline = T, addgrid.col = "darkgray", 
         order="hclust", addrect = 4, rect.col = "black", rect.lwd = 5,
         cl.pos = "b", tl.col = "indianred4", tl.cex = 1, cl.cex = 1, addCoef.col = "white", 
         number.digits = 2, number.cex = 0.75, 
         col = colorRampPalette(c("darkred","white","midnightblue"))(100))




#matrice di correlazione se
cor.matrix <- cor(num.df[,13:22])



corrplot(cor.matrix, method = "color", outline = T, addgrid.col = "darkgray", 
         order="hclust", addrect = 4, rect.col = "black", rect.lwd = 5,
         cl.pos = "b", tl.col = "indianred4", tl.cex = 1, cl.cex = 1, addCoef.col = "white", 
         number.digits = 2, number.cex = 0.75, 
         col = colorRampPalette(c("darkred","white","midnightblue"))(100))





#matrice di correlazione worst
cor.matrix <- cor(num.df[,22:32])



corrplot(cor.matrix, method = "color", outline = T, addgrid.col = "darkgray", 
         order="hclust", addrect = 4, rect.col = "black", rect.lwd = 5,
         cl.pos ="b", tl.col = "indianred4", tl.cex = 1, cl.cex = 1, addCoef.col = "white", 
         number.digits = 2, number.cex = 0.75, 
         col = colorRampPalette(c("darkred","white","midnightblue"))(100))

# inizio del machine learning
library(e1071)
# Dichiariamo due funzioni per il calcolo del MR e dell'Accuracy in modo da utilizzarle
# per misurare la bont? del modello che andremo a costruire sul training set
model.SVM <- svm(diagnosis ~ ., df, kernel="polynomial", cost=10, degree=10) # serve per le regressioni e le calssificazioni e misura la densit?
summary(model.SVM)
# Usiamo il modello per fare delle previsioni su i dati usati nella parte di training
y.pred <- predict(model.SVM, df)
# Misurare la qualit? del modello, costruiamo la function per svolgere pi? volte la stessa oprerazione
MR <- function(y.pred, y.true) {
  res <- mean(y.pred != y.true)   #seve per capire quanto sbaglia il nostro modello, frequenza errori
  return(res)   # res = media vettore booleana ? 1 se y pred ? diversa da y true, conto la frequenza delle volte che sbaglia
}
# possiamo fare la stessa cosa per l'accutazza anche tramite chiamata ricorsivs
Acc <- function(y.pred, y.true) {
  res <- 1 - mean(y.pred != y.true)
  #res <- 1 - MR(y.pred, y.true)
  return(res)
}
# Valutiamo la performance del modello sul dataset con il training
MR.linear <- MR(y.pred, df$diagnosis)
MR.linear

Acc.linear <- Acc(y.pred, df$diagnosis)
Acc.linear

# Visualizziamo la performance(accuratezza) al variare del grado del polinomio
MR.total <- 1:10
for (d in 1:10) {
  model.SVM <- svm(diagnosis ~ ., df, kernel="polynomial", cost=10, degree=d) # costruimamo un vettore dove salviamo i miss classification error al variare del polinomio
  y.pred <- predict(model.SVM, df)# istanziamo un mmodello fdi tipo polinomiale, nella quale vogliamo predirre un trget, caloclo prediction sul df
  MR.poly <- MR(y.pred, df$diagnosis)#calcolo misclassifiction errore e lo vado sovrasscrivere nel vettore di prima
  MR.total[d] <- MR.poly# mis classification errore calcolate per il grado d
}
plot(MR.total, type='p', xlab="Degree", ylim=c(0, 1))# sembra che su 3 ci sia il dato minimo

# Abbiamo visto che il punto di minimo si ha in cost=1 e deg=3 # addestriamo il nostro modello con costo 10
model.SVM <- svm(diagnosis ~ ., df, kernel="polynomial", cost=10, degree=3)
y.pred <- predict(model.SVM, df)
MR.poly <- MR(y.pred, df$diagnosis)
MR.poly # ho mr 1% quindi significa che l'1% dei dati viene classificata male

# Valutiamo la performance sul Test Set
y.pred <- predict(model.SVM, df.test)# predizione sui dati di test
MR.poly <- MR(y.pred, df.test$diagnosis)
MR.poly #il 41% 
# valutiamo il test sull accuratezza
y.pred <- predict(model.SVM, df.test)# predizione sui dati di test
Acc.poly <- Acc(y.pred, df.test$diagnosis)
Acc.poly# 95% di accuratezza del modello
# Visualizziamo la performance al variare del grado
MR.total <- 1:10
MR.train <- 1:10
for (d in 1:10) {
  model.SVM <- svm(diagnosis ~., df.train, kernel="polynomial", cost=10, degree=d) 
  y.pred<- predict(model.SVM,df.val)
  MR.poly <- MR(y.pred,df.val$diagnosis)
  MR.total[d] <- MR.poly
  y2.pred<-predict(model.SVM,df.train)
  MR.train[d] <- MR(y2.pred,df.train$diagnosis)
}
plot(MR.total, type='p', xlab="Degree", ylim=c(0, 1), col = "red", main = "Variazione dell'MR al variare del grado")
points(MR.train, col = "blue")
bestDegree <- which.min(MR.total)
#Visualizziamo la performace al variare del costo
for (d in 1:10) {
  model.SVM <- svm(diagnosis ~., df.train, kernel="polynomial", cost=d, degree= bestDegree) 
  y.pred<- predict(model.SVM,df.val)
  MR.poly <- MR(y.pred,df.val$diagnosis)
  MR.total[d] <- MR.poly
  y2.pred<-predict(model.SVM,df.train)
  MR.train[d] <- MR(y2.pred,df.train$diagnosis)
}
plot(MR.total, type='p', xlab="Cost", ylim=c(0, 1), col = "red", main = "Variazione dell'MR al variare del costo")
points(MR.train, col = "blue")
bestCost <- which.min(MR.total)
# Testiamo il modello sul test set
model.SVM <- svm(diagnosis ~., df.train, kernel="polynomial", cost = bestCost, degree = bestDegree) 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM,df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)
#punto 10
# Approccio Probabilistico
SVM.probs <- svm(diagnosis ~ ., data=df, kernel="polynomial", cost=bestCost, degree = bestDegree, probability=TRUE)
y.pred <- predict(SVM.probs, df.test , probability=TRUE)
y.probs <- attr(y.pred, "probabilities")
y.probs <- y.probs[,2] 
# Convertire y.probs in un vettore di predizioni
y.total <- rep(0, 48)
y.total[y.probs > 0.3]

#questa perch? non prende in pasto la svm
MR2 <- function(y.pred, y.true) { 
  y.true <- as.numeric(as.factor(y.true))
  y.true[y.true ==1] <- 0
  y.true[y.true ==2] <- 1
  res <- mean(y.pred != y.true) 
  return(res)
}
Acc2 <- function(y.pred, y.true) { 
  y.true <- as.numeric(as.factor(y.true))
  y.true[y.true ==1] <- 0
  y.true[y.true ==2] <- 1
  res <- 1 - mean(y.pred != y.true) 
  return ( res )
}

#performance che variano al variare del treshold
MR2(y.total , df.test$diagnosis)
Acc2(y.total, df.test$diagnosis)
# Stampo la Confusion Matrix
cf_table <- table(y.pred, df.test$diagnosis)
#install.packages("caret")
library(caret)
fourfoldplot(cf_table, color = c("cyan", "pink"),
             conf.level = 0, margin = 1, main = "Confusion Matrix")
#Curva di ROC e AUC
#install.packages ( "ROCR" )
library (ROCR)
pred <- prediction(y.probs, df.test$diagnosis) 
perf <- performance(pred , "tpr" , "fpr")
# AUC
auc <- performance ( pred , "auc" ) 
auc <- auc@y.values [[1]]
plot(perf , colorize=TRUE, main=auc)

#punto 11
for(i in 1:20){
  
  df2<-na.omit(df2)
  
  #splitting del dataset senza outlier
  N<-nrow(df2)
  #splitting
  N.train <- 350
  N.test <- 48
  N.val <- 60
  
  
  train.sample <- sample(N, N.train) # costruire un vettore di elementi che va da 1 a n degli ntrain
  df.train <- df2[train.sample, ] # [righe, colonne] estrazione degli elementiper costruire i dataset di training
  print(-train.sample)
  df.test <- df2[-train.sample, ]
  
  val.sample <- sample(N.test + N.val, N.val)# costruzione set di validation, estraiamo un vettore di n val, da 1 a nval+ntest
  df.val <- df.test[val.sample, ]
  print(-val.sample)
  df.test <- df.test[-val.sample, ]
  
  
  #addestriamo il modello, il nostro degree migliore è 1 e il nostro cost migliore è 2
  model.SVM <- svm(diagnosis ~ ., df.train, kernel="polynomial", cost=10, degree=1)
  
  y.pred <- predict(model.SVM, df.train)
  
  #aggiorno mr train con i nuovi valori 
  MR.train <- MR(y.pred, df.train$diagnosis)
  
  model.SVM <- svm(diagnosis ~ ., df.test, kernel="polynomial", cost=10, degree=1)
  
  y.pred <- predict(model.SVM, df.test)
  
  #aggiorno mr test con i nuovi valori
  MR.test <- MR(y.pred, df.test$diagnosis)
  
  #uso la statistica descrittiva per descrivere statisticamente il campione
  
  #parte per radius_mean
  #statistica descrittiva
  mean <- mean(df.train$radius_mean, na.rm = TRUE)
  median <- median(df.train$radius_mean, na.rm = TRUE)
  min <- min(df.train$radius_mean, na.rm = TRUE)
  max <- max(df.train$radius_mean, na.rm = TRUE)
  range <- range(df.train$radius_mean, na.rm = TRUE)
  quantile <- quantile(df.train$radius_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$radius_mean, na.rm = TRUE)
  sd <- sd(df.train$radius_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["radius_mean"]]
  
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
  
  
  
  #texture_mean
  #statistica descrittiva
  mean <- mean(df.train$texture_mean, na.rm = TRUE)
  median <- median(df.train$texture_mean, na.rm = TRUE)
  min <- min(df.train$texture_mean, na.rm = TRUE)
  max <- max(df.train$texture_mean, na.rm = TRUE)
  range <- range(df.train$texture_mean, na.rm = TRUE)
  quantile <- quantile(df.train$texture_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$texture_mean, na.rm = TRUE)
  sd <- sd(df.train$texture_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["texture_mean"]]
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
  
  
  
  
  # perimeter_mean
  #statistica descrittiva
  mean <- mean(df.train$perimeter_mean, na.rm = TRUE)
  median <- median(df.train$perimeter_mean, na.rm = TRUE)
  min <- min(df.train$perimeter_mean, na.rm = TRUE)
  max <- max(df.train$perimeter_mean, na.rm = TRUE)
  range <- range(df.train$perimeter_mean, na.rm = TRUE)
  quantile <- quantile(df.train$perimeter_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$perimeter_mean, na.rm = TRUE)
  sd <- sd(df.train$perimeter_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["perimeter_mean"]]
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
  
  
  
  # area_mean
  #statistica descrittiva
  mean <- mean(df.train$area_mean, na.rm = TRUE)
  median <- median(df.train$area_mean, na.rm = TRUE)
  min <- min(df.train$area_mean, na.rm = TRUE)
  max <- max(df.train$area_mean, na.rm = TRUE)
  range <- range(df.train$area_mean, na.rm = TRUE)
  quantile <- quantile(df.train$area_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$area_mean, na.rm = TRUE)
  sd <- sd(df.train$area_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["area_mean"]]
  
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
  
  
  # smoothness_mean
  #statistica descrittiva
  mean <- mean(df.train$smoothness_mean, na.rm = TRUE)
  median <- median(df.train$smoothness_mean, na.rm = TRUE)
  min <- min(df.train$smoothness_mean, na.rm = TRUE)
  max <- max(df.train$smoothness_mean, na.rm = TRUE)
  range <- range(df.train$smoothness_mean, na.rm = TRUE)
  quantile <- quantile(df.train$smoothness_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$smoothness_mean, na.rm = TRUE)
  sd <- sd(df.train$smoothness_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["smoothness_mean"]]
  
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
  
  
  
  # compactness_mean
  #statistica descrittiva
  mean <- mean(df.train$compactness_mean, na.rm = TRUE)
  median <- median(df.train$compactness_mean, na.rm = TRUE)
  min <- min(df.train$compactness_mean, na.rm = TRUE)
  max <- max(df.train$compactness_mean, na.rm = TRUE)
  range <- range(df.train$compactness_mean, na.rm = TRUE)
  quantile <- quantile(df.train$compactness_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$compactness_mean, na.rm = TRUE)
  sd <- sd(df.train$compactness_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["compactness_mean"]]
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
  
  
  
  
  # concavity_mean
  #statistica descrittiva
  mean <- mean(df.train$concavity_mean, na.rm = TRUE)
  median <- median(df.train$concavity_mean, na.rm = TRUE)
  min <- min(df.train$concavity_mean, na.rm = TRUE)
  max <- max(df.train$concavity_mean, na.rm = TRUE)
  range <- range(df.train$concavity_mean, na.rm = TRUE)
  quantile <- quantile(df.train$concavity_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$concavity_mean, na.rm = TRUE)
  sd <- sd(df.train$concavity_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["concavity_mean"]]
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
  
  
  
  # concave.points_mean
  #statistica descrittiva
  mean <- mean(df.train$concave.points_mean, na.rm = TRUE)
  median <- median(df.train$concave.points_mean, na.rm = TRUE)
  min <- min(df.train$concave.points_mean, na.rm = TRUE)
  max <- max(df.train$concave.points_mean, na.rm = TRUE)
  range <- range(df.train$concave.points_mean, na.rm = TRUE)
  quantile <- quantile(df.train$concave.points_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$concave.points_mean, na.rm = TRUE)
  sd <- sd(df.train$concave.points_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["concave.points_mean"]]
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
  
  
  
  
  
  # symmetry_mean
  #statistica descrittiva
  mean <- mean(df.train$symmetry_mean, na.rm = TRUE)
  median <- median(df.train$symmetry_mean, na.rm = TRUE)
  min <- min(df.train$symmetry_mean, na.rm = TRUE)
  max <- max(df.train$symmetry_mean, na.rm = TRUE)
  range <- range(df.train$symmetry_mean, na.rm = TRUE)
  quantile <- quantile(df.train$symmetry_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$symmetry_mean, na.rm = TRUE)
  sd <- sd(df.train$symmetry_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["symmetry_mean"]]
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
  
  
  # fractal_dimension_mean
  #statistica descrittiva
  mean <- mean(df.train$fractal_dimension_mean, na.rm = TRUE)
  median <- median(df.train$fractal_dimension_mean, na.rm = TRUE)
  min <- min(df.train$fractal_dimension_mean, na.rm = TRUE)
  max <- max(df.train$fractal_dimension_mean, na.rm = TRUE)
  range <- range(df.train$fractal_dimension_mean, na.rm = TRUE)
  quantile <- quantile(df.train$fractal_dimension_mean, na.rm = TRUE, prob = seq(0, 1, 0.25))
  var <- var(df.train$fractal_dimension_mean, na.rm = TRUE)
  sd <- sd(df.train$fractal_dimension_mean, na.rm = TRUE)
  
  
  tab <- matrix(c(mean, median, min, max, var, sd,quantile, MR.train, MR.test), ncol=13, byrow=TRUE)
  colnames(tab) <- c('Media','Mediana','Min','Max', 'Varianza','Sd', 'Quantile 0%','Q. 25%','Q. 50%','Q. 75%','Q. 100%', 'MR_train', 'MR_test')
  tab <- as.table(tab)
  print(tab)
  
  
  #grafici
  
  ##plotta l'intero dataset, anche le variabili non numeriche
  #install.packages("funModeling")
  library(funModeling)
  plot_num(df2)
  
  
  #statistica inferenziale
  x <- df.train[["fractal_dimension_mean"]]
  
  library(fitdistrplus)
  descdist(x, discrete = FALSE)
  normal.dist <- fitdist(x, "norm")
  plot(normal.dist)
  
  
  n <- 300
  alpha <- 0.05
  m <- mean(x)
  s <- sqrt(var(x))
  zalfa <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  c1 <- m - zalfa * s / sqrt(n)
  c2 <- m + zalfa * s / sqrt(n)
}

# inizio punto 12
model.SVM <- svm(diagnosis~ radius_mean + texture_mean, df.train, kernel="polynomial", cost = bestCost, degree = bestDegree) 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ radius_mean + texture_mean , df.train, kernel="linear") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)


model.SVM <- svm(diagnosis ~ radius_mean + texture_mean , df.train, kernel="radial") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ perimeter_mean  + area_mean , df.train, kernel="polynomial", cost = bestCost, degree = bestDegree) 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ perimeter_mean + area_mean, df.train, kernel="linear") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ perimeter_mean + area_mean, df.train, kernel="radial") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ radius_mean + texture_mean + perimeter_mean, df.train, kernel="polynomial", cost = bestCost, degree = bestDegree) 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ radius_mean + texture_mean + perimeter_mean, df.train, kernel="linear") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ radius_mean + texture_mean + perimeter_mean, df.train, kernel="radial") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ concavity_mean + concave.points_mean, df.train, kernel="polynomial", cost = bestCost, degree = bestDegree) 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ concavity_mean + concave.points_mean, df.train, kernel="linear") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ concavity_mean + concave.points_mean, df.train, kernel="radial") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ smoothness_mean + compactness_mean , df.train, kernel="polynomial", cost = bestCost, degree = bestDegree) 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ smoothness_mean + compactness_mean , df.train, kernel="linear") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ smoothness_mean + compactness_mean , df.train, kernel="radial") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ symmetry_mean  + fractal_dimension_mean , df.train, kernel="polynomial", cost = bestCost, degree = bestDegree) 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ symmetry_mean  + fractal_dimension_mean , df.train, kernel="linear") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ symmetry_mean  + fractal_dimension_mean , df.train, kernel="radial") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ radius_mean + texture_mean +
                   perimeter_mean + area_mean +
                   concavity_mean + symmetry_mean +
                  fractal_dimension_mean, df.train, kernel="polynomial", cost = bestCost, degree = bestDegree) 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ radius_mean + texture_mean +
                   perimeter_mean + area_mean +
                   concavity_mean + symmetry_mean +
                   fractal_dimension_mean, df.train, kernel="linear") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)

model.SVM <- svm(diagnosis ~ radius_mean + texture_mean +
                   perimeter_mean + area_mean +
                   concavity_mean + symmetry_mean +
                   fractal_dimension_mean, df.train, kernel="radial") 
# Valutiamo la performance sul Test Set
y.pred<-predict(model.SVM, df.test)
MR.test <- MR(y.pred, df.test$diagnosis)
sprintf("Missclassification Rate: %f    Percentuale: %.2f%%", MR.test, MR.test*100)
y.pred<-predict(model.SVM,df.test)
Acc.test <- Acc(y.pred, df.test$diagnosis)
sprintf("Accuracy: %f    Percentuale: %.2f%%", Acc.test, Acc.test*100)


